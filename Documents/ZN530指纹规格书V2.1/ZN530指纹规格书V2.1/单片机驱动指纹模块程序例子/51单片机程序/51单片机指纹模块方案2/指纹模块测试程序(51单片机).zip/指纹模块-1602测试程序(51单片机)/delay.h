#ifndef __DELAY_H__
#define __DELAY_H__

#include<reg52.h>
void Delay_Ms(int);
void Delay_Us(int);

#endif
